﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;

public static class NativeKeyboard
{
    static TaskCompletionSource<object> initializeTCS;

    static AndroidJavaObject inputFieldManager;

    static Dictionary<int, NativeInputField> fields = new Dictionary<int, NativeInputField>();
    static Dictionary<int, TaskCompletionSource<(int id, AndroidJavaObject nativeObj)>> fieldTCSs = new Dictionary<int, TaskCompletionSource<(int id, AndroidJavaObject nativeObj)>>();

    public delegate void VisibleHeightChangedDelegate(float visibleHeightRatio);
    public static event VisibleHeightChangedDelegate VisibleHeightChanged;

    public delegate void FieldEventDelegate(NativeInputField field);

    public static event FieldEventDelegate PreparingKeyboard;
    public static event FieldEventDelegate EnterPressed;
    public static event FieldEventDelegate EditEnd;

    public delegate void KeyboardStateChangedDelegate(bool shown);
    public static event KeyboardStateChangedDelegate KeyboardStateChanged;

    public static bool KeyboardVisible { get; private set; }

    public static Task Initialize()
    {
        if (initializeTCS != null)
            return initializeTCS.Task;

        var ni = NativeInterop.Instance;

        ni.EditEnd += OnEditEnd;
        ni.EnterPressed += OnEnterPressed;
        ni.FieldCreated += OnFieldCreated;
        ni.FocusChanged += OnFocusChanged;
        ni.VisibleHeightChanged += OnVisibleHeightChanged;
        ni.InitDone += OnInitDone;
        ni.PreparingKeyboard += OnPreparingKeyboard;
        ni.TextChanged += OnTextChanged;

        initializeTCS = new TaskCompletionSource<object>();

        foreach (var r in Screen.cutouts)
            Debug.Log(r);
        if (ni.Initialize(Screen.cutouts.Any()))
            CompleteInit();

        return initializeTCS.Task;
    }

    static void CompleteInit()
    {
        try
        {
            inputFieldManager = NativeInterop.Instance.GetInputFieldManager();
            initializeTCS?.TrySetResult(null);
        }
        catch (Exception ex)
        {
            initializeTCS?.TrySetException(ex);
        }
    }

    static void OnInitDone() => CompleteInit();

    public static void Destroy()
    {
        var ni = NativeInterop.Instance;

        ni.EditEnd -= OnEditEnd;
        ni.EnterPressed -= OnEnterPressed;
        ni.FieldCreated -= OnFieldCreated;
        ni.FocusChanged -= OnFocusChanged;
        ni.VisibleHeightChanged -= OnVisibleHeightChanged;
        ni.InitDone -= OnInitDone;
        ni.PreparingKeyboard -= OnPreparingKeyboard;
        ni.TextChanged -= OnTextChanged;

        fields.Clear();
        fieldTCSs.Clear();
        initializeTCS = null;
    }

    public static Task<(int id, AndroidJavaObject nativeObj)> CreateField(NativeInputField field, InputFieldParams fieldParams)
    {
        var tcs = new TaskCompletionSource<(int id, AndroidJavaObject nativeObj)>();
        var id = NativeInterop.Instance.CreateField(inputFieldManager, fieldParams);
        fields[id] = field;
        fieldTCSs[id] = tcs;
        return tcs.Task;
    }

    static void OnFieldCreated(int id)
    {
        if (fieldTCSs.TryGetValue(id, out var tcs))
        {
            tcs.SetResult((id, NativeInterop.Instance.GetField(inputFieldManager, id)));
            fieldTCSs.Remove(id);
        }
    }

    public static void DestroyField(NativeInputField field)
    {
        if (field.IsInitialized)
        {
            fields.Remove(field.ID);
            NativeInterop.instance.DestroyField(field.NativeObject);
        }
    }

    static void OnVisibleHeightChanged(int visibleHeight)
    {
        var ratio = visibleHeight / (float)Screen.height;
        if (ratio >= 0.9f)
            ratio = 1.0f;

        VisibleHeightChanged?.Invoke(ratio);

        var visible = ratio < 0.999f;
        KeyboardVisible = visible;
        KeyboardStateChanged?.Invoke(visible);
    }

    static void OnTextChanged(int id, string text)
    {
        if (fields.TryGetValue(id, out var field))
            field.OnTextChanged(text);
    }

    static void OnPreparingKeyboard(int id)
    {
        if (fields.TryGetValue(id, out var field))
        {
            PreparingKeyboard?.Invoke(field);
            field.OnPreparingKeyboard();
        }
    }

    static void OnFocusChanged(int id, bool focus)
    {
        if (fields.TryGetValue(id, out var field))
            field.OnFocusChanged(focus);
    }

    static void OnEnterPressed(int id)
    {
        if (fields.TryGetValue(id, out var field))
        {
            EnterPressed?.Invoke(field);
            field.OnEnterPressed();
        }
    }

    static void OnEditEnd(int id, string text)
    {
        if (fields.TryGetValue(id, out var field))
        {
            EditEnd?.Invoke(field);
            field.OnEditEnd(text);
        }
    }

    //?? There's this stuff in the original, I don't know if it does anything useful yet
    /*
        private void OnApplicationPause (bool pauseStatus) {
            if (!pauseStatus) {
                if (_data != null) {
                    OnData (_data);
                } else if (_error != null) {
                    OnError (_error);
                }
            }
        }

        /// <summary>
        /// Handler on app focus
        /// </summary>
        void OnApplicationFocus (bool focusStatus) {
            if (!focusStatus) {
                foreach (var item in _instance._inputs.Values) {
                    item.Hide ();
                }
            }
        }
     */
}
