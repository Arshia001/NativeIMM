﻿#pragma warning disable IDE0044 // Add readonly modifier, allow fields to be written by Unity
#pragma warning disable CS0162 // Unreachable code detected, generated due to conditional compilation

using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Events;

//?? probably needs some work to be usable in the editor, if necessary at all
[RequireComponent(typeof(TMP_InputField))]
public class NativeInputField : MonoBehaviour
{
    public delegate void TextChangedDelegate(string text);
    public event TextChangedDelegate TextChanged;

    public delegate void FocusChangedDelegate(bool focus);
    public event FocusChangedDelegate FocusChanged;

    public event Action PreparingKeyboard;
    public event Action EnterPressed;


    [SerializeField] bool blurOnTouchOutside = true;
    [SerializeField] UnityEvent _EnterPressed = default;

    public TMP_InputField InputField { get; private set; }

    Canvas canvas;

    bool visible;
    bool focused;
    bool eanbled;

    [SerializeField] ReturnKeyType returnKeyType = default;
    [SerializeField] Typeface typeface = default;
    [SerializeField] string customTypefaceAsset = default;
    public ReturnKeyType ReturnKeyType => returnKeyType;

    public string Text
    {
        get => InputField.text;

        private set
        {
            InputField.text = value;
            TextChanged?.Invoke(value);
        }
    }

    public int ID { get; private set; }

    public AndroidJavaObject NativeObject { get; private set; }

    public bool IsInitialized => NativeObject != null;

    RectInt lastScreenRect;


    void Awake()
    {
        InputField = GetComponent<TMP_InputField>();
        canvas = GetComponentInParent<Canvas>();
    }

    void Start()
    {
#if UNITY_ANDROID && !UNITY_EDITOR
        InitializeNativeField();
#endif
    }

    async void InitializeNativeField()
    {
        try
        {
            await NativeKeyboard.Initialize();

            (ID, NativeObject) = await NativeKeyboard.CreateField(this, GetFieldParams());

            SetText(Text);
            SetVisible(visible);
            SetFocus(focused);
            SetEnabled(enabled);
            UpdateNativeRect();

            InputField.enabled = false;
            InputField.textViewport.gameObject.SetActive(false);
            InputField.textComponent.gameObject.SetActive(false);
            InputField.placeholder.gameObject.SetActive(false);
        }
        catch (Exception ex)
        {
            Debug.LogError("Failed to initialize field");
            Debug.LogException(ex);
        }
    }

    void Update()
    {
        if (blurOnTouchOutside)
        {
            var rect = GetScreenRect();
            foreach (var touch in Input.touches)
                if (touch.phase == TouchPhase.Began && !rect.Contains(new Vector2Int((int)touch.position.x, (int)touch.position.y)))
                {
                    SetFocus(false);
                    break;
                }
        }

        UpdateNativeRect();
    }

    RectInt GetScreenRect()
    {
        var rect = InputField.textComponent.transform as RectTransform;
        var corners = new Vector3[4];
        rect.GetWorldCorners(corners);
        float xMin = float.PositiveInfinity, xMax = float.NegativeInfinity, yMin = float.PositiveInfinity, yMax = float.NegativeInfinity;

        for (int i = 0; i < 4; i++)
        {
            Vector3 screenCoord;
            if (canvas.renderMode == RenderMode.ScreenSpaceOverlay)
                screenCoord = corners[i];
            else
                screenCoord = RectTransformUtility.WorldToScreenPoint(Camera.main, corners[i]);

            if (screenCoord.x < xMin)
                xMin = screenCoord.x;
            if (screenCoord.x > xMax)
                xMax = screenCoord.x;
            if (screenCoord.y < yMin)
                yMin = screenCoord.y;
            if (screenCoord.y > yMax)
                yMax = screenCoord.y;
        }

        return new RectInt(Mathf.RoundToInt(xMin), Mathf.RoundToInt(yMin), Mathf.RoundToInt(xMax - xMin), Mathf.RoundToInt(yMax - yMin));
    }

    RectInt GetNativeScreenRect()
    {
        var rect = GetScreenRect();
        return new RectInt(rect.xMin, Screen.height - rect.yMax, rect.width, rect.height);
    }

    void UpdateNativeRect()
    {
        if (IsInitialized)
        {
            var rect = GetNativeScreenRect();
            if (!rect.Equals(lastScreenRect))
            {
                NativeInterop.Instance.SetRect(NativeObject, rect.x, rect.y, rect.width, rect.height);
                lastScreenRect = rect;
            }
        }
    }

    void OnDestroy() => NativeKeyboard.DestroyField(this);

    void OnEnable() => SetVisible(true);

    void OnDisable() => SetVisible(false);

    public void SetVisible(bool visible)
    {
        this.visible = visible;
        if (IsInitialized)
            NativeInterop.Instance.SetVisible(NativeObject, visible);
    }

    private void OnApplicationFocus(bool focus)
    {
        if (!focus && focused)
            SetFocus(false);
    }

    public void SetFocus(bool focused)
    {
        this.focused = focused;
        if (IsInitialized)
            NativeInterop.Instance.SetFocus(NativeObject, focused);
    }

    public void SetEnabled(bool enabled)
    {
        this.enabled = enabled;
        if (IsInitialized)
            NativeInterop.Instance.SetEnabled(NativeObject, enabled);
    }

    public void SetText(string text)
    {
        Text = text;
        if (IsInitialized)
            NativeInterop.Instance.SetText(NativeObject, text);
    }

    internal void OnTextChanged(string text) => Text = text;

    internal void OnEditEnd(string text) => Text = text;

    internal void OnPreparingKeyboard() => PreparingKeyboard?.Invoke();

    internal void OnFocusChanged(bool focus)
    {
        FocusChanged?.Invoke(focus);
    }

    internal void OnEnterPressed()
    {
        EnterPressed?.Invoke();
        _EnterPressed?.Invoke();
    }

    InputFieldParams GetFieldParams()
    {
        var rect = GetNativeScreenRect();
        var scaleFactor = rect.height / (InputField.transform as RectTransform).rect.height;
        var placeholder = InputField.placeholder as TMP_Text;
        var text = InputField.textComponent;

        return new InputFieldParams
        {
            Placeholder = placeholder.text,
            PlaceholderColor = placeholder.color,
            CharacterLimit = InputField.characterLimit,
            FontSize = text.fontSize * scaleFactor,
            Bold = text.fontStyle.HasFlag(FontStyles.Bold),
            Italic = text.fontStyle.HasFlag(FontStyles.Italic),
            TextColor = text.color,
            Alignment = GetTextAnchor(text.alignment), //?? could probably support a few more modes here
            ContentType = InputField.contentType,
            Multiline = InputField.multiLine,
            KeyboardType = InputField.keyboardType,
            InputType = InputField.inputType,
            ReturnKeyType = returnKeyType,
            Typeface = typeface,
            CustomTypefaceAsset = customTypefaceAsset,
            X = rect.x,
            Y = rect.y,
            Width = rect.width,
            Height = rect.height
        };
    }

    TextAnchor GetTextAnchor(TextAlignmentOptions alignment)
    {
        var horizontal =
            alignment.HasFlag((TextAlignmentOptions)_HorizontalAlignmentOptions.Left) ? 0 :
            alignment.HasFlag((TextAlignmentOptions)_HorizontalAlignmentOptions.Right) ? 2 : 1;

        var vertical =
            alignment.HasFlag((TextAlignmentOptions)_VerticalAlignmentOptions.Top) ? 0 :
            alignment.HasFlag((TextAlignmentOptions)_VerticalAlignmentOptions.Bottom) ? 2 : 1;

        var tuple = (horizontal, vertical);

        return
            tuple == (0, 0) ? TextAnchor.UpperLeft :
            tuple == (0, 1) ? TextAnchor.MiddleLeft :
            tuple == (0, 2) ? TextAnchor.LowerLeft :
            tuple == (2, 0) ? TextAnchor.UpperRight :
            tuple == (2, 1) ? TextAnchor.MiddleRight :
            tuple == (2, 2) ? TextAnchor.LowerRight :
            tuple == (1, 0) ? TextAnchor.UpperCenter :
            tuple == (1, 2) ? TextAnchor.LowerCenter :
            TextAnchor.MiddleCenter;
    }
}
