﻿using NotSoSimpleJSON;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum ReturnKeyType
{
    Default,
    Next,
    Done,
    Search
}

public enum Typeface
{
    Default,
    Serif,
    SansSerif,
    Monospace,
    Custom
}

public class InputFieldParams
{
    public string Placeholder { get; set; }
    public double FontSize { get; set; }
    public int X { get; set; }
    public int Y { get; set; }
    public int Width { get; set; }
    public int Height { get; set; }
    public int CharacterLimit { get; set; }
    public Color32 TextColor { get; set; }
    public Color32 PlaceholderColor { get; set; }
    public TMPro.TMP_InputField.ContentType ContentType { get; set; }
    public TMPro.TMP_InputField.InputType InputType { get; set; }
    public TouchScreenKeyboardType KeyboardType { get; set; }
    public ReturnKeyType ReturnKeyType { get; set; }
    public TextAnchor Alignment { get; set; }
    public bool Multiline { get; set; }
    public Typeface Typeface { get; set; }
    public string CustomTypefaceAsset { get; set; }
    public bool Bold { get; set; }
    public bool Italic { get; set; }

    string TranslateToJavaName(string name) => char.ToLower(name[0]) + name.Substring(1);

    void SetColor(AndroidJavaObject obj, string name, Color32 color)
    {
        obj.Set(name + "A", (int)color.a);
        obj.Set(name + "R", (int)color.r);
        obj.Set(name + "G", (int)color.g);
        obj.Set(name + "B", (int)color.b);
    }

    public AndroidJavaObject ToJavaObject()
    {
        var obj = new AndroidJavaObject("ir.onehand.nativeimm.InputFieldParams");
        obj.Set(TranslateToJavaName(nameof(Placeholder)), Placeholder);
        obj.Set(TranslateToJavaName(nameof(FontSize)), FontSize);
        obj.Set(TranslateToJavaName(nameof(X)), X);
        obj.Set(TranslateToJavaName(nameof(Y)), Y);
        obj.Set(TranslateToJavaName(nameof(Width)), Width);
        obj.Set(TranslateToJavaName(nameof(Height)), Height);
        obj.Set(TranslateToJavaName(nameof(CharacterLimit)), CharacterLimit);
        obj.Set(TranslateToJavaName(nameof(ContentType)), ContentType.ToString());
        obj.Set(TranslateToJavaName(nameof(InputType)), InputType.ToString());
        obj.Set(TranslateToJavaName(nameof(KeyboardType)), KeyboardType.ToString());
        obj.Set(TranslateToJavaName(nameof(ReturnKeyType)), ReturnKeyType.ToString());
        obj.Set(TranslateToJavaName(nameof(Alignment)), Alignment.ToString());
        obj.Set(TranslateToJavaName(nameof(Multiline)), Multiline);
        obj.Set(TranslateToJavaName(nameof(Typeface)), Typeface.ToString());
        obj.Set(TranslateToJavaName(nameof(CustomTypefaceAsset)), CustomTypefaceAsset);
        obj.Set(TranslateToJavaName(nameof(Bold)), Bold);
        obj.Set(TranslateToJavaName(nameof(Italic)), Italic);

        SetColor(obj, TranslateToJavaName(nameof(TextColor)), TextColor);
        SetColor(obj, TranslateToJavaName(nameof(PlaceholderColor)), PlaceholderColor);

        return obj;
    }
}

class NativeInterop : MonoBehaviour
{
    public static NativeInterop instance;
    public static NativeInterop Instance
    {
        get
        {
            if (instance == null)
            {
                // Name used by native code, do not rename
                var go = new GameObject("NativeKeyboard");
                DontDestroyOnLoad(go);

                instance = go.AddComponent<NativeInterop>();
            }

            return instance;
        }
    }

    public delegate void VisibleHeightChangedDelegate(int visibleHeight);
    public event VisibleHeightChangedDelegate VisibleHeightChanged;

    public delegate void InitDoneDelegate();
    public event InitDoneDelegate InitDone;

    public delegate void FieldCreatedDelegate(int id);
    public event FieldCreatedDelegate FieldCreated;

    public delegate void PreparingKeyboardDelegate(int id);
    public event PreparingKeyboardDelegate PreparingKeyboard;

    public delegate void EditEndDelegate(int id, string text);
    public event EditEndDelegate EditEnd;

    public delegate void EnterPressedDelegate(int id);
    public event EnterPressedDelegate EnterPressed;

    public delegate void TextChangedDelegate(int id, string text);
    public event TextChangedDelegate TextChanged;

    public delegate void FocusChangedDelegate(int id, bool focus);
    public event FocusChangedDelegate FocusChanged;

    public delegate void ErrorReceivedDelegate(string code, string message, JSONObject data);
    public event ErrorReceivedDelegate ErrorReceived;

    [Obsolete("For native interop, do not access directly")]
    public void ReceiveData(string dataString)
    {
        var json = JSON.Parse(dataString);
        var name = json["name"].AsString;
        var args = json["args"].AsObject;
        var id = args["id"].AsInt;

        switch (name)
        {
            case "KB_HEIGHT_CHANGED":
                VisibleHeightChanged?.Invoke(args["visibleHeight"].AsInt.Value);
                break;

            case "INIT_DONE":
                InitDone?.Invoke();
                break;

            case "FIELD_CREATED":
                FieldCreated?.Invoke(id.Value);
                break;

            case "PREPARING_KEYBOARD":
                PreparingKeyboard?.Invoke(id.Value);
                break;

            case "EDIT_END":
                EditEnd?.Invoke(id.Value, args["text"].AsString);
                break;

            case "ENTER_PRESSED":
                EnterPressed?.Invoke(id.Value);
                break;

            case "TEXT_CHANGED":
                TextChanged?.Invoke(id.Value, args["text"].AsString);
                break;

            case "FOCUS_CHANGED":
                FocusChanged?.Invoke(id.Value, args["focus"].AsBool.Value);
                break;
        }
    }

    [Obsolete("For native interop, do not access directly")]
    public void ReceiveError(string dataString)
    {
        var json = JSON.Parse(dataString);
        var code = json["code"].AsString;
        var message = json["message"].AsString;
        var data = json["data"].AsObject;

        Debug.LogError($"NativeKeyboard native error '{code}': {message}");

        ErrorReceived?.Invoke(code, message, data);
    }

    public bool Initialize(bool includeNotchInHeight)
    {
        using (var type = new AndroidJavaClass("ir.onehand.nativeimm.UnityInterop"))
            return type.CallStatic<bool>("initialize", includeNotchInHeight);
    }

    public void Destroy()
    {
        using (var type = new AndroidJavaClass("ir.onehand.nativeimm.UnityInterop"))
            type.CallStatic("destroy");
    }

    public AndroidJavaObject GetInputFieldManager()
    {
        using (var type = new AndroidJavaClass("ir.onehand.nativeimm.UnityInterop"))
            return type.CallStatic<AndroidJavaObject>("getInputFieldManager");
    }

    public int CreateField(AndroidJavaObject inputFieldManager, InputFieldParams inputFieldParams) =>
        inputFieldManager.Call<int>("create", inputFieldParams.ToJavaObject());

    public AndroidJavaObject GetField(AndroidJavaObject inputFieldManager, int id) =>
        inputFieldManager.Call<AndroidJavaObject>("getField", id);

    public void SetText(AndroidJavaObject inputField, string text) =>
        inputField.Call("setText", text);

    public void SetRect(AndroidJavaObject inputField, int x, int y, int width, int height) =>
        inputField.Call("setRect", x, y, width, height);

    public void SetVisible(AndroidJavaObject inputField, bool visible) =>
        inputField.Call("setVisible", visible);

    public void SetFocus(AndroidJavaObject inputField, bool focus) =>
        inputField.Call("setFocus", focus);

    public void SetEnabled(AndroidJavaObject inputField, bool enabled) =>
        inputField.Call("setEnabled", enabled);

    public void DestroyField(AndroidJavaObject inputField) =>
        inputField.Call("destroy");
}
