package ir.onehand.nativeimm

const val LOG_TAG = "NativeIMM"