package ir.onehand.nativeimm

class InputReceiverParams {
    var multiline = false
    var contentType = ""
    var inputType = ""
    var keyboardType = ""
    var returnKeyType = ""
}
